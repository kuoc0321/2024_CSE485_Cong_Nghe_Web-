<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xem chi tiết</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/bootstrap-5.3.2/css/bootstrap.min.css')); ?>">
</head>
<body>
    <h2 class="text-center text-uppercase text-decoration-underline text-success">Actor Detail</h2>

    <div class="container">
        <div class="row">
            <h3 class="text-center text-success">Actor</h3>
            <table class="table table-dark table-striped align-middle">
                <thead>
                    <tr>
                        <th class="col-6" scope="col">Thuộc tính</th>
                        <th class="col-6" scope="col">Giá trị</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Actor ID</td>
                        <td><?php echo e($actor->id); ?></td>
                    </tr>
                    <tr>
                        <td>First name</td>
                        <td><?php echo e($actor->firstname); ?></td>
                    </tr>
                    <tr>
                        <td>Last name</td>
                        <td><?php echo e($actor->lastname); ?></td>
                    </tr>
                    <tr>
                        <td>Last update</td>
                        <td><?php echo e($actor->lastupdate); ?></td>
                    </tr>
                    <tr>
                        <td>Film</td>
                        <td><?php echo e($actor->film); ?></td>
                    </tr>
              
                
                </tbody>
            </table>       
        </div>
     
        <p class="d-flex justify-content-end"><a href="<?php echo e(route('actors.index', ['actor' => $actor->id, 'pageIndex' => $pageIndex])); ?>" class=""><button class="btn btn-primary fw-bold">Trở lại</button></a></p>
    </div>
    
    <script src="<?php echo e(asset('assets/fontawesome/js/all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/bootstrap-5.3.2/js/bootstrap.bundle.min.js')); ?>"></script>
</body>
</html><?php /**PATH C:\laragon\www\ActorInfo\resources\views/show.blade.php ENDPATH**/ ?>