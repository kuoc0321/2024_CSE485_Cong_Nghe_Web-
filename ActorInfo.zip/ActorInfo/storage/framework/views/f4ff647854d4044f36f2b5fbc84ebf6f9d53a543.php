<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang chủ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

</head>
<body>
    
    <h2 class="text-center text text-success my-4 text-uppercase text-decoration-underline">List Actor</h2>


    <div class="container">
        <a href="<?php echo e(route('actors.create')); ?>">
            <button class="btn btn-success mb-3"><i class="fa-regular fa-square-plus"></i>Add Actor</button>
        </a>
        <div class="row">

            <table class="table table-primary table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                    <th scope="col">Actor Id</th>
                    <th scope="col">FirstName</th>
                    <th scope="col">Last Name</th>
                    <th scope="col">Last update</th>
                    <th scope="col">Film</th>
                    <th scope="col" class="text-center" colspan="3">Chỉnh sửa</th>
                    </tr>
                </thead>
                <tbody>
                        <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($item->id); ?></th>
                                <td><?php echo e($item->firstname); ?></td>
                                <td><?php echo e($item->lastname); ?></td>
                                <td><?php echo e($item->lastupdate); ?></td>
                                <td><?php echo e($item->film); ?></td>


                                
                                <td ><a class="btn btn-success" href="<?php echo e(route('actors.show', ['actor' => $item->id, 'pageIndex' => $pageIndex])); ?>"><i class="bi bi-eye"></i></a></td>
                                <td ><a class="btn btn-danger" href="<?php echo e(route('actors.edit', ['actor' => $item->id, 'pageIndex' => $pageIndex])); ?>"><i class="bi bi-pencil"></i></a></td>
                                <td ><button class="btn btn-warning" data-bs-toggle='modal'   data-bs-target='#A<?php echo e($item->id); ?>'><i class="bi bi-trash"></i></button></td>
                                

                                <!-- Modal -->
                                <div class='modal fade' id='A<?php echo e($item->id); ?>' tabindex='-1' aria-labelledby='exampleModalLabel' aria-hidden='true'>
                                    <div class='modal-dialog'>
                                        <div class='modal-content'>
                                            <div class='modal-header'>
                                                <h1 class='modal-title fs-5' id='exampleModalLabel'>Xác nhận xóa</h1>
                                                <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                                            </div>
                                            <div class='modal-body'>
                                                Bạn có muốn sinh viên có id: <?php echo e($item->id); ?>

                                            </div>
                                            <div class='modal-footer'>
                                                <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Trở lại</button>
                                                <form action="<?php echo e(route('actors.destroy', ['pageIndex' => $pageIndex, 'actor' => $item->id])); ?>" method="POST">
                                                    <?php echo csrf_field(); ?> 
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit"  class='btn btn-primary'>Đồng ý</button>
                                                </form>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>       
        </div>
    </div>

    <!-- paginating  -->
    <?php if($numberOfPage > 1): ?>
    <div class="d-flex justify-content-center align-items-center my-2">
         <a class="btn btn-success" href="<?php echo e(route('actors.index', ['pageIndex' => $pageIndex - 1])); ?>">Trước</a>  
         <?php for($i = 1; $i <= $numberOfPage; $i++): ?>
            <?php if($pageIndex == $i): ?>
                <a class="btn btn-primary ms-2" href="<?php echo e(route('actors.index', ['pageIndex' => $i])); ?>"><?php echo e($i); ?></a> 
            <?php else: ?>
                
                <?php if($i == 1 || $i == $numberOfPage || ($i <= $pageIndex + 4 && $i >= $pageIndex - 4)): ?>
                    <a class="btn btn-success ms-2" href="<?php echo e(route('actors.index', ['pageIndex' => $i])); ?>"><?php echo e($i); ?></a>
                <?php elseif($i == $pageIndex - 5 || $i == $pageIndex + 5): ?>
                    <a class="btn btn-success ms-2" href="<?php echo e(route('actors.index', ['pageIndex' => $i])); ?>">...</a>
                <?php endif; ?>
            <?php endif; ?>
         <?php endfor; ?>
         <a class="btn btn-success ms-2" href="<?php echo e(route('actors.index', ['pageIndex' => $pageIndex + 1])); ?>">Sau</a>
    </div>
    <?php endif; ?>


    <!-- modal inform -->

   
    <div id="myDialog" style="display: none;" class="px-5 py-3 rounded-3">
        <h4 class="text-primary fw-bold fs-4">Thông báo</h4>
        <p class="text-success"><?php echo e(session('mes')); ?></p>
        <button id="confirmButton" class="float-end rounded-2">Đồng ý</button>
    </div>
    <style>
        #myDialog {
            position: fixed;
            width: 500px;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #ffffff;
            padding: 20px;
            border: 1px solid #ccc;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        #confirmButton {
        padding: 10px 20px;
        background: #007bff;
        color: #ffffff;
        border: none;
        cursor: pointer;
        }
    </style>
    <?php if(session('mes')): ?>
        <script>
            var dialog = document.getElementById("myDialog");
            var confirmButton = document.getElementById("confirmButton");

            dialog.style.display = "block";
            confirmButton.addEventListener("click", function() {
                dialog.style.display = "none";
            });
        </script>
    <?php endif; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('assets/fontawesome/js/all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/bootstrap-5.3.2/js/bootstrap.bundle.min.js')); ?>"></script>
</body>
</html><?php /**PATH C:\laragon\www\ActorInfo\resources\views/index.blade.php ENDPATH**/ ?>