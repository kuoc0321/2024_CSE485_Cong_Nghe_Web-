<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
use App\Models\Actor;
class ActorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $f = Faker::create();
       
        for($i=0;$i<=30;$i++){
            Actor::create(
                [
                    'firstname' => $f->firstName,
                    'lastname' => $f->lastName,
                    'lastupdate' => $f->dateTime(),
                    'film' => $f->randomNumber
                ]
            );
        }
        
    }
}
