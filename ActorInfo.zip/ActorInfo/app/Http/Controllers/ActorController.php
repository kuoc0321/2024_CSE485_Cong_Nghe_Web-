<?php

namespace App\Http\Controllers;

use App\Models\Actor;
use Illuminate\Http\Request;

class ActorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $numberOfRecord = Actor::count();
        $perPage = 20;
        $numberOfPage = $numberOfRecord % $perPage == 0?
            (int) ($numberOfRecord / $perPage): (int) ($numberOfRecord / $perPage) + 1;
        $pageIndex = 1;
        if($request->has('pageIndex'))
            $pageIndex = $request->input('pageIndex');
        if($pageIndex < 1) $pageIndex = 1;
        if($pageIndex > $numberOfPage) $pageIndex = $numberOfPage;
         // thiết lập theo trang
        $actors = Actor::orderByDesc('id')  // đưa vào view
                ->skip(($pageIndex-1)*$perPage)
                ->take($perPage)
                ->get();  
         // dd($arr);
        return view('index', compact('actors','numberOfPage', 'pageIndex')) ;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $actors = Actor::all();
        return view('create', compact('actors'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Actor::create($request->all());
        return redirect()->route('actors.index')->with('mes', 'Thêm thành công');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\actor  $actor
     * @return \Illuminate\Http\Response
     */
    public function show(actor $actor,request $request)
    {
        $pageIndex = 1;
        if($request->has('pageIndex')) $pageIndex = $request->input('pageIndex');
        // show
        return view('show', compact('actor', 'pageIndex'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\actor  $actor
     * @return \Illuminate\Http\Response
     */
    public function edit(actor $actor, Request $request)
    {
        $pageIndex = 1;
        if($request->has('pageIndex')) $pageIndex = $request->input('pageIndex');
        // show form edit
        $actors = Actor::all();
        return view('edit', compact('actor', 'actors', 'pageIndex'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\actor  $actor
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, actor $actor)
    {
        $pageIndex = 1;
        if($request->has('pageIndex')) $pageIndex = $request->input('pageIndex');
        // echo $pageIndex;
        // update
        $actor->update($request->all());
        return redirect()->route('actors.index', ['pageIndex' => $pageIndex])->with('mes', 'Cập nhật thành công!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\actor  $actor
     * @return \Illuminate\Http\Response
     */
    public function destroy(actor $actor, Request $request)
    {
        $pageIndex = 1;
        if($request->has('pageIndex'))  $pageIndex = $request->input('pageIndex');
        $actor->delete();
        return redirect()->route('actors.index', ['pageIndex' => $pageIndex])->with('mes', 'Xóa thành công');
    }
}
