<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Article;
use Faker\Factory as Faker;
 
class ArticleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $f = Faker::create();
        for($i = 0;$i < 10;$i++) {
            Article::creat(
                [
                'title' => $f->sentence(),
                'content' => $f->paragraph(3, true),
                ]
            );
    }}
}
