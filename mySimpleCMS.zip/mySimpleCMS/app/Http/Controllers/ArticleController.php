<?php

namespace App\Http\Controllers;

use App\Models\Article;
use Illuminate\Http\Request;
class ArticleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $numberOfRecord = Article::count();
        $perPage = 5;
        $numberOfPage = $numberOfRecord % $perPage == 0?
            (int) ($numberOfRecord / $perPage): (int) ($numberOfRecord / $perPage) + 1;
        $pageIndex = 1;
        if($request->has('pageIndex'))
            $pageIndex = $request->input('pageIndex');
        if($pageIndex < 1) $pageIndex = 1;
        if($pageIndex > $numberOfPage) $pageIndex = $numberOfPage;
         // thiết lập theo trang
        $articles = Article::orderByDesc('id')  
                ->skip(($pageIndex-1)*$perPage)
                ->take($perPage)
                ->get();  
         // dd($arr);
        return view('index', compact( 'articles', 'numberOfPage', 'pageIndex')) ;  //Trả về View
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $articles = Article::All();
        return view('create', compact('articles'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Article::create($request->All());
        return redirect()->route('articles.index')->with('success', 'Article created successfully.');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Article  $article
     * @return \Illuminate\Http\Response
     */
    public function show(Article $article, Request $request)
    {
        $pageIndex = 1;
        if($request->has('pageIndex')) $pageIndex = $request->input("pageIndex");
        return view('show', compact('article','pageIndex'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Article  $article
     * @return \Illuminate\Http\Response
     */
    public function edit(Article $article, Request $request)
    {
        $pageIndex = 1;
        if($request->has('pageIndex')) $pageIndex = $request->input("pageIndex");
        // Show from edit page
        $articles = Article::all();
        return view('edit', compact('article','pageIndex'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Article  $article
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Article $article)
    {
        $pageIndex = 1;
        if($request->has('pageIndex')) $pageIndex = $request->input('pageIndex');
        // echo $pageIndex;
        // update
        $article->update($request->all());
        return redirect()->route('articles.index', ['pageIndex' => $pageIndex])->with('mes', 'Cập nhật thành công!'); 
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Article  $article
     * @return \Illuminate\Http\Response
     */
    public function destroy(Article $article, request $request)
    {
        $pageIndex = 1;
        if($request->has('pageIndex')) $pageIndex=$request->input('pageIndex');
        $article->delete();
        return redirect()->route('articles.index',['pageIndex'=>$pageIndex])->with('mes', "Article deleted successfully.");
    }
}
